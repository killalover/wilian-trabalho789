import logo from '../../assets/logo.png';

import caixa from '../../assets/eletronicos/caixa.png';
import fone from '../../assets/eletronicos/fone.png';
import headset from '../../assets/eletronicos/headset.png';
import iphone from '../../assets/eletronicos/iphone.png';
import notebook from '../../assets/eletronicos/notebook.png';

const cesta = {
  topo: {
    titulo: "Detalhe da cesta",
  },
  detalhes: {
    nome: "Compra de Eletrônicos",
    logoLoja: logo,
    nomeLoja: "NLA Eletrônicos",
    descricao: "Explore a inovação na nossa loja de tecnologia. Descubra os mais recentes gadgets e dispositivos para tornar sua vida mais conectada e inteligente."
  },
  itens: {
    titulo: "Itens da cesta",
    lista: [
      {
        nome: "Caixa de Som Bluetooth JBL",
        imagem: caixa,
        preco: "R$ 299,99",
        botao: "Adicionar a cesta"
      },
      {
        nome: "Fone Bluetooth Branco",
        imagem: fone,
        preco: "R$ 75,00",
        botao: "Adicionar a cesta"
      },
      {
        nome: "Fne Headset Bluetooth 5.1",
        imagem: headset,
        preco: "R$ 219,90",
        botao: "Adicionar a cesta"
      },
      {
        nome: "iPhone 13 pro Max.",
        imagem: iphone,
        preco: "R$ 4.799,00",
        botao: "Adicionar a cesta"
      },
      {
        nome: "Notebook Samsung Book x20 Np550 Core I5-10210",
        imagem: notebook,
        preco: "R$ 1.499,90",
        botao: "Adicionar a cesta"
      }
    ]
  }
}

export default cesta;